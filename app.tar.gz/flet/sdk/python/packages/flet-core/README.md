# Flet core library

The library is the foundation of Flet framework and is not intended to be used directly.

Install [`flet` module](https://pypi.org/project/flet/) to use Flet framework.