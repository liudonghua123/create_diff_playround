package com.appveyor.flet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
