class AssetSrc {
  final String path;
  final bool isFile;

  const AssetSrc({required this.path, required this.isFile});
}
