class FilePickerUploadFile {
  final String name;
  final String uploadUrl;
  final String method;

  FilePickerUploadFile(
      {required this.name, required this.uploadUrl, required this.method});
}
