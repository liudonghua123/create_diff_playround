class AppBecomeActivePayload {
  AppBecomeActivePayload();

  factory AppBecomeActivePayload.fromJson(Map<String, dynamic> json) =>
      AppBecomeActivePayload();
}
