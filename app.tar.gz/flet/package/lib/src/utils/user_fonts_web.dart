import 'dart:typed_data';

Future<ByteData> fetchFontFromFile(String path) async {
  throw UnimplementedError();
}
