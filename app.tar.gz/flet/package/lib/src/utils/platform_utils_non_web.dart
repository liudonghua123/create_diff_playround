bool isProgressiveWebApp() {
  return false;
}

String getFletRouteUrlStrategy() {
  return "";
}

bool isFletWebPyodideMode() {
  return false;
}

void openPopupBrowserWindow(
    String url, String windowName, int minWidth, int minHeight) {}
